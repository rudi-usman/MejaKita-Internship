console.log("main.js has been connected");
