<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="container">
    <div class="row">
        <div class="col"></div>
        <h1>Hello, world!</h1>
    </div>
</div>
<?= $this->endSection(); ?>